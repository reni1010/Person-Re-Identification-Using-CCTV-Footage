import cv2
from ultralytics import YOLO
from deep_sort_realtime.deepsort_tracker import DeepSort
from sklearn.metrics.pairwise import cosine_similarity
from collections import defaultdict

tracker1 = DeepSort(max_age=100)
tracker2 = DeepSort(max_age=100)
track_features = defaultdict(list)

cap1 = cv2.VideoCapture(r"C:\Users\USER\Desktop\ppl\v1.mp4")#custom1.mp4
cap2 = cv2.VideoCapture(r"C:\Users\USER\Desktop\ppl\v2.mp4")#custom2.mp4
model = YOLO("yolov8n.pt")

frame_count = 0

while True:
    ret, frame1 = cap1.read()
    ret, frame2 = cap2.read()
    
    if not ret: break
    frame_count += 1
    if not frame_count % 5: continue

    results1 = model(frame1)
    bbs1 = []
    for r in results1:
        boxes = r.boxes
        for ind in range(len(boxes)):
            box = boxes[ind]
            if r.names[int(box.cls[0])] not in ['person','people','pedestrian']:continue
            x1, y1, x2, y2 = box.xyxy[0]
            _, _, w, h = box.xywh[0]
            bbs1.append(([x1,y1,w,h],int(box.conf[0]),int(box.cls[0])))
    trackers1 = tracker1.update_tracks(bbs1, frame = frame1)

    results2 = model(frame2)
    bbs2 = []
    for r in results2:
        boxes = r.boxes
        for ind in range(len(boxes)):
            box = boxes[ind]
            if r.names[int(box.cls[0])] not in ['person','people','pedestrian']:continue
            x1, y1, x2, y2 = box.xyxy[0]
            _, _, w, h = box.xywh[0]
            bbs2.append(([x1,y1,w,h],int(box.conf[0]),int(box.cls[0])))
    trackers2 = tracker2.update_tracks(bbs2, frame = frame2)
    
    for tracker in trackers1+trackers2:
        if not tracker.is_confirmed(): continue

        feature1 = tracker.get_feature()
        max_similarity = 0.0
        matched_track_id = None

        for track_id, features in track_features.items():
            if features:
                similarity = cosine_similarity([feature1], [features[-1]])[0][0]
                if similarity > max_similarity:
                    max_similarity = similarity
                    matched_track_id = track_id
        print(max_similarity)
        if matched_track_id is None or max_similarity < 0.86:
            matched_track_id = len(track_features) + 1
            track_features[matched_track_id].append(feature1)
        #tracker.track_id = str(matched_track_id)
        
        curr = frame1 if (tracker in trackers1) else frame2
        bbox = tracker.to_tlbr()
        cv2.rectangle(curr, (int(bbox[0]), int(bbox[1])), (int(bbox[2]), int(bbox[3])), (0, 255, 0), 2)
        cv2.putText(curr, str(matched_track_id), (int(bbox[0]), int(bbox[1]) + 20), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2)

    cv2.imshow("frame1", cv2.resize(frame1,(600,360)))
    cv2.imshow("frame2", cv2.resize(frame2,(600,360)))
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap1.release()
cap2.release()
cv2.destroyAllWindows()




import matplotlib.pyplot as plt
trajectories = [
    [(100, 100), (120, 120), (150, 130), (180, 140)],
    [(200, 200), (220, 220), (250, 230), (280, 240)],
   
]
fig, ax = plt.subplots(figsize=(8, 6))

for trajectory in trajectories:
    x, y = zip(*trajectory)  
    ax.plot(x, y, marker='o')
ax.set_title("Person Re-Identification Trajectories")
ax.set_xlabel("X-coordinate")
ax.set_ylabel("Y-coordinate")
ax.legend([f"Person {i+1}" for i in range(len(trajectories))])
plt.grid(True)
plt.show()

